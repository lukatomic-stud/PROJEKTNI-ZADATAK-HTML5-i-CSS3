
<section class="contact-page">
    <h1>Kontakt</h1>
    <h2>Javi nam se ili pošalji upit</h2>

    <div class="map-wrap">
    <iframe 
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2781.7671851881296!2d15.897709776517493!3d45.79589177108148!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4765d15caddaabe1%3A0x36ab29638beda58c!2sUl.%20Ive%20Tijardovi%C4%87a%2016%2C%2010000%2C%20Zagreb!5e0!3m2!1sen!2shr!4v1768331817802!5m2!1sen!2shr" 
        width="600" height="450" style="border:0;" 
        allowfullscreen="" 
        loading="lazy" 
        referrerpolicy="no-referrer-when-downgrade">

    </iframe>
    </div>

    <form class="contact-form" action="#" method="post">
        <div class="form-row">
            <label for="firstName">Ime <span class="req">*</span></label>
            <input
                type="text"
                id="firstName"
                name="firstName"
                placeholder="Upiši ime..."
                required>
        </div>

        <div class="form-row">
            <label for="lastName">Prezime <span class="req">*</span></label>
            <input
                type="text"
                id="lastName"
                name="lastName"
                placeholder="Upiši prezime..."
                required>
        </div>

        <div class="form-row">
            <label for="email">E-mail adresa <span class="req">*</span></label>
            <input
                type="email"
                id="email"
                name="email"
                placeholder="Upiši e-mail..."
                required>
        </div>

        <div class="form-row">
            <label for="country">Država</label>
            <select id="country" name="country">
                <option value="">Odaberi državu</option>
                <option value="HR">Hrvatska</option>
                <option value="SI">Slovenija</option>
                <option value="BA">Bosna i Hercegovina</option>
                <option value="RS">Srbija</option>
                <option value="HU">Mađarska</option>
                <option value="AT">Austrija</option>
                <option value="DE">Njemačka</option>
            </select>
        </div>

        <div class="form-row">
            <label for="message">Opis</label>
            <textarea
                id="message"
                name="message"
                rows="5"
                placeholder="Upiši poruku..."></textarea>
        </div>

        <button class="btn" type="submit">Pošalji</button>
    </form>
</section>

