<nav>
    <ul>
        <li><a href="index.php?menu=1" <?php if ($menu == 1) echo 'class="active"'; ?>>Početna</a></li>
        <li><a href="index.php?menu=2" <?php if ($menu == 2) echo 'class="active"'; ?>>Novosti</a></li>
        <li><a href="index.php?menu=11" <?php if ($menu == 11) echo 'class="active"'; ?>>Usponi</a></li>
        <li><a href="index.php?menu=12" <?php if ($menu == 12) echo 'class="active"'; ?>>Moj dnevnik</a></li>
        <li><a href="index.php?menu=3" <?php if ($menu == 3) echo 'class="active"'; ?>>Galerija</a></li>
        <li><a href="index.php?menu=4" <?php if ($menu == 4) echo 'class="active"'; ?>>O nama</a></li>
        <li><a href="index.php?menu=5" <?php if ($menu == 5) echo 'class="active"'; ?>>Kontakt</a></li>
    </ul>
</nav>