<footer>
    <div class="footer-content">
        <p>© 2026 Penjački dnevnik.</p>

        <div class="social-links">
            <a href="https://www.facebook.com" target="_blank" aria-label="Facebook">
                <img src="images/facebook.png" alt="Facebook ikona">
            </a>
            <a href="https://www.instagram.com" target="_blank" aria-label="Instagram">
                <img src="images/instagram.png" alt="Instagram ikona">
            </a>
            <a href="https://github.com/lukatomic-stud/PROJEKTNI-ZADATAK-HTML5-i-CSS3" target="_blank" aria-label="GitHub repozitorij">
                <img src="images/github.png" alt="GitHub repozitorij">
            </a>
        </div>
    </div>
</footer>

</body>
</html>